({
	doInit : function(component, event, helper) {
       helper.getCases(component, event, helper);                      
	},
    navigateToCase : function(component, event, helper) {
       helper.navigateToCaseDetail(component, event, helper);                      
	}
})